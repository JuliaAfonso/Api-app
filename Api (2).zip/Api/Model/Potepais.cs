﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Model
{
    public class Potepais
    {

        public char IDPAIS { get; set; }

        public char IDPOTE { get; set; }
    }
}
