﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Model
{
    public class MembroGrupo
    {
        public int IdGrupo { get; set; }
        public int IdPais { get; set; }
    }
}


// criar o der
// arrumar os erros aq
// verificar se o visual code ta certo



