﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Model
{
    public class Paises
    {
        public int idpais { get; set; }

        public string nome { get; set; }

        public bool pais_sede { get; set; }

        public int renkingfifa { get; set; }

        public int idconfederacao {get; set;}

    }
}
