﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Model
{
    public class Confederacao
    {
        public int idconfederacao { get; set; }

        public string nome { get; set; }

        public string sigla { get; set; }


    }
}
