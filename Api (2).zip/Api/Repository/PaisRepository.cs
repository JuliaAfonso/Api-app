﻿using Api.Context;
using Api.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Repository
{
    public class PaisRepository : IPaisRepository
    {
        private  AppDbContext _appContext = null;

        public PaisRepository(AppDbContext appContext)
        {
            _appContext = appContext;
        }

        public void Adicionar(Paises p)
        {
            //insert into ....
            _appContext.paises.Add(p);
        }

        public void Atualizar(Paises p)
        {//update tabela set .... where id...
            _appContext.paises.Update(p);
            _appContext.SaveChanges();
        }

        public Paises ObterPorId(int id)
        {
            //select * from paises where idpais = id
            return _appContext.paises.Where(p => p.idpais == id).FirstOrDefault();
        }

        public IEnumerable<Paises> ObterTodosOsPaises()
        { //select * from paises
            return _appContext.paises.ToList();
        }

        public void Remover(int id)
        {//delete from ...
            var pais = ObterPorId(id);
            _appContext.Remove(pais);
            _appContext.SaveChanges();
        }
    }
}
