﻿using Api.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Repository
{
    public interface IGrupo
    {
    
        public IEnumerable<Grupo> ObterTodosOsGrupos();

        public Grupo ObterPorId(int id);

        public void Adicionar(Grupo g);

        public void Atualizar(Grupo g);

        public void Remover(int id);



    }
}
