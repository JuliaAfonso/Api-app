﻿using Api.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Api.Repository
{
    public interface IMembrogrupoRepository
    {

        public IEnumerable<MembroGrupo> ObterPorMembroGrupo(int idGrupo);

        public MembroGrupo ObterPorId(int id);

        public void Adicionar(MembroGrupo m);

        public void Atualizar(MembroGrupo m);

        public void Remover(int id);



    }
}

