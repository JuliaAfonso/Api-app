﻿using Api.Context;
using Api.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Repository
{
    public class PotePaisRepository : IPotePaisRepository
    {
        private AppDbContext _appContext = null;

        public PotePaisRepository(AppDbContext appContext)
        {
            _appContext = appContext;
        }

        public void Adicionar(Potepais a)
        {
            _appContext.Potepais.Add(a);
        }

        public Potepais ObterPorId(int idPais, int idPote)
        {

            return _appContext.Potepais.Where(a => a.IDPAIS == idPais && 
                                                    a.IDPOTE == idPote
            ).FirstOrDefault();
        }

        public IEnumerable<Potepais> ObterTodosOsPaisesPorPote(int idPote)
        {
            //select * from potepais where idpote = ??
            return _appContext.Potepais.Where(p => p.IDPOTE == idPote).ToList();
        }


        public void Remover(int idPais, int idPote)
        {
            var Potepais = ObterPorId(idPais, idPote);
            _appContext.Remove(Potepais);
            _appContext.SaveChanges();
        }
    }
}

