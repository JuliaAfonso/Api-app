﻿using Api.Context;
using Api.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Repository
{
    public class MembrogrupoRepository : IMembrogrupoRepository
    {
        private AppDbContext _appContext = null;

        public MembrogrupoRepository(AppDbContext appContext)
        {
            _appContext = appContext;
        }

        public void Adicionar(MembroGrupo m)
        {
            //insert into ....
            _appContext.MembrosGrupo.Add(m);
        }

        public void Atualizar(MembroGrupo m)
        {//update tabela set .... where id...
            _appContext.MembrosGrupo.Update(m);
            _appContext.SaveChanges();
        }

        public IEnumerable<MembroGrupo> ObterPorMembroGrupo(int idGrupo)
        {
            return _appContext.MembrosGrupo.Where(m => m.IdGrupo == idGrupo).ToList();
        }

        public MembroGrupo ObterPorId(int id)
        {
            return _appContext.MembrosGrupo.Where(m => m.IdGrupo == id).FirstOrDefault();
        }

      

        public void Remover(int id)
        {//delete from ...
            var MembroGrupo = ObterPorId(id);
            _appContext.Remove(MembroGrupo);
            _appContext.SaveChanges();
        }
    }
}

