﻿using Api.Context;
using Api.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Api.Repository
{
    public class GrupoRepository : IGrupo
    {
        private AppDbContext _appContext = null;

        public GrupoRepository(AppDbContext appContext)
        {
            _appContext = appContext;
        }

        public void Adicionar(Grupo g)
        {
            //insert into ....
            _appContext.Grupos.Add(g);
        }

        public void Atualizar(Grupo g)
        {//update tabela set .... where id...
            _appContext.Grupos.Update(g);
            _appContext.SaveChanges();
        }

        public IEnumerable<Grupo> ObterPorGrupo()
        {
            throw new NotImplementedException();
        }

        public Grupo ObterPorId(int id)
        {
            //select * from paises where idpais = id
            return _appContext.Grupos.Where(g => g.IdGrupo == id).FirstOrDefault();
        }

        public IEnumerable<Grupo> ObterTodosOsGrupos()
        { //select * from paises
            return _appContext.Grupos.ToList();
        }

        public void Remover(int id)
        {//delete from ...
            var Grupo = ObterPorId(id);
            _appContext.Remove(Grupo);
            _appContext.SaveChanges();
        }
    }
}

