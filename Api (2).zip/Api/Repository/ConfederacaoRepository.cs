﻿using Api.Context;
using Api.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Repository
{
    public class ConfederacaoRepository : IConfederacaoRepository
    {
        private AppDbContext _appContext = null;

        public ConfederacaoRepository(AppDbContext appContext)
        {
            _appContext = appContext;
        }

        public void Adicionar(Confederacao c)
        {
            _appContext.Confederacao.Add(c);
        }

        public void Atualizar(Confederacao c)
        {
            _appContext.Confederacao.Update(c);
            _appContext.SaveChanges();
        }

        public Confederacao ObterPorId(int id)
        {

            return _appContext.Confederacao.Where(c => c.idconfederacao == id).FirstOrDefault();
        }

        public IEnumerable<Confederacao> ObterTodasAsConfederacao()
        {
            return _appContext.Confederacao.ToList();
        }

        public void Remover(int id)
        {
            var Confederacao = ObterPorId(id);
            _appContext.Remove(Confederacao);
            _appContext.SaveChanges();
        }
    }
}
