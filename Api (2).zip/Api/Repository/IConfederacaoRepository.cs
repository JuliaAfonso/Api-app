﻿using Api.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Repository
{
    public interface IConfederacaoRepository
    {
        public IEnumerable<Confederacao> ObterTodasAsConfederacao();

        public Confederacao ObterPorId(int id);

        public void Adicionar(Confederacao c);

        public void Atualizar(Confederacao c);

        public void Remover(int id);
    }
}
