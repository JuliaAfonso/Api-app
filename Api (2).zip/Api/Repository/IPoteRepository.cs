﻿using Api.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Repository
{
    public interface IPoteRepository
    {
        public IEnumerable<Pote> ObterTodosOsPotes();

        public Pote ObterPorId(int id);

        public void Adicionar(Pote o);

        public void Atualizar(Pote o);

        public void Remover(int id);
    }
}
