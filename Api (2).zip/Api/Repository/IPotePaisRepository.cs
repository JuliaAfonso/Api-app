﻿using Api.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Repository
{
    public interface IPotePaisRepository
    {
        
        public IEnumerable<Potepais> ObterTodosOsPaisesPorPote(int idPote);
        public Potepais ObterPorId(int idPais, int idPote);
        public void Adicionar(Potepais a);

        public void Remover(int idPais, int idPote);
    
        }

}
