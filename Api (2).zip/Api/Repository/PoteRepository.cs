﻿using Api.Context;
using Api.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Repository
{
    public class PoteRepository : IPoteRepository
    {

        private AppDbContext _appContext = null;

        public PoteRepository(AppDbContext appContext)
        {
            _appContext = appContext;
        }

        public void Adicionar(Pote o)
        {
            _appContext.Pote.Add(o);
        }

        public void Atualizar(Pote o)
        {
            _appContext.Pote.Update(o);
            _appContext.SaveChanges();
        }

        public Pote ObterPorId(int id)
        {

            return _appContext.Pote.Where(o => o.idpote == id).FirstOrDefault();
        }

        public IEnumerable<Pote> ObterTodosOsPotes()
        {
            return _appContext.Pote.ToList();
        }

        public void Remover(int id)
        {
            var Pote = ObterPorId(id);
            _appContext.Remove(Pote);
            _appContext.SaveChanges();
        }
    }
}
