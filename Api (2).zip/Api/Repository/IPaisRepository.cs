﻿using Api.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Repository
{
    public interface IPaisRepository
    {
        //quais as acoes que fazemos com o pai
        //buscar todos os paises
        public IEnumerable<Paises> ObterTodosOsPaises();

        public Paises ObterPorId(int id);

        public void Adicionar(Paises p);
        
        public void Atualizar(Paises p);

        public void Remover(int id);



    }
}
