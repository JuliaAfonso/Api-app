﻿using Api.Model;
using Microsoft.EntityFrameworkCore;


namespace Api.Context
{
    public class AppDbContext: DbContext
    {
        public AppDbContext()
        { }
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        { }
        public DbSet<Paises> paises { get; set; }

        public DbSet<Confederacao> Confederacao { get; set; }

        public DbSet<Pote> Pote { get; set; }

        public DbSet<Potepais> Potepais { get; set; }

        public DbSet<Grupo> Grupos { get; set; }

        public DbSet<MembroGrupo> MembrosGrupo { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.ApplyConfigurationsFromAssembly(typeof(AppDbContext).Assembly);
        }
    }
}
