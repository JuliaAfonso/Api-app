﻿using Api.Model;
using Api.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Controller
{
    [Route("api/[controller]")]
    public class MembroGrupoController : ControllerBase
    {
        private IMembrogrupoRepository _contexto;

        public MembroGrupoController(IMembrogrupoRepository contexto)
        {
            _contexto = contexto;
        }

        //api/pais/ObterTodosOsMembroGrupo
        [HttpGet]
        [Route("ObterTodosOsMembroGrupo/{id}")]
        public IActionResult ObterTodosOsMembroGrupo(int id)
        {
            var listaMembroGrupo = _contexto.ObterPorMembroGrupo(id);
            return Ok(listaMembroGrupo);
        }

        [HttpGet]
        [Route("ObterPorId/{id}")]
        public IActionResult ObterPorId(int id)
        {
            var MembroGrupoBusca = _contexto.ObterPorId(id);
            if (MembroGrupoBusca == null)
                return NotFound("MembroGrupo não encontrado");
            return Ok(MembroGrupoBusca);
        }

        [HttpPost]
        [Route("Adicionar")]
        public IActionResult Adicionar(MembroGrupo m)
        {
            _contexto.Adicionar(m);
            return Ok("MembroGrupo Adicionado com sucesso!");
        }

        [HttpPut]
        [Route("Atualizar/{id}")]
        public IActionResult Atualizar(int id, MembroGrupo m)
        {
            var MembroGrupo = _contexto.ObterPorId(id);
            if (MembroGrupo == null)
            {
                return NotFound("MembroGrupo não existe, atualização não pode ser realizada!");
            }
            _contexto.Atualizar(m);
            return Ok("MembroGrupo atualizado com sucesso!");
        }

        [HttpDelete]
        [Route("Remover/{id}")]
        public IActionResult Remover(int id)
        {
            var MembroGrupo = _contexto.ObterPorId(id);
            if (MembroGrupo == null)
            {
                return NotFound("MembroGrupo não existe, remoção não pode ser realizada!");
            }
            _contexto.Remover(id);
            return Ok();
        }
    }
}
