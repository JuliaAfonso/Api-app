﻿using Api.Model;
using Api.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Api.Controller
{
    [Route("api/[controller]")]
    public class PotePaisController : ControllerBase
    {
        private IPotePaisRepository _contexto;

        public PotePaisController(IPotePaisRepository contexto)
        {
            _contexto = contexto;
        }

        //api/potes/ObterTodosOsPotesEPaises
        [HttpGet]
        [Route("ObterTodosOsPotesEPaises/{id}")]
        public IActionResult ObterTodosOsPotesEPaises(int id)
        {
            var listaPaises = _contexto.ObterTodosOsPaisesPorPote(id);
            return Ok(listaPaises);
        }

      

        [HttpPost]
        [Route("Adicionar")]
        public IActionResult Adicionar(Potepais o)
        {
            _contexto.Adicionar(o);
            return Ok("Pote Adicionado com sucesso!");
        }


        [HttpDelete]
        [Route("Remover/{idPote}/{idPais}")]
        public IActionResult Remover(int idPote,int idPais)
        {
            
            _contexto.Remover(idPais,idPote);
            return Ok();
        }
    }
}

