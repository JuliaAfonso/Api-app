﻿using Api.Model;
using Api.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Grupo = Api.Model.Grupo;

namespace Api.Controller
{
    [ApiController]
    [Route("[controller]")]
    public class GrupoController : ControllerBase
    {
        private IGrupo _contexto;

        public GrupoController(IGrupo contexto)
        {
            _contexto = contexto;
        }

        //api/pais/ObterTodosOsGrupos
        [HttpGet]
        public IActionResult ObterTodosOsGrupos()
        {
            var listaGrupos = _contexto.ObterTodosOsGrupos();
            return Ok(listaGrupos);
        }

        [HttpGet]
        [Route("ObterPorId/{id}")]
        public IActionResult ObterPorId(int id)
        {
            var GrupoBusca = _contexto.ObterPorId(id);
            if (GrupoBusca == null)
                return NotFound("Grupo não encontrado");
            return Ok(GrupoBusca);
        }

        [HttpPost]
        [Route("Adicionar")]
        public IActionResult Adicionar(Grupo g)
        {
            _contexto.Adicionar(g);
            return Ok("Grupo Adicionado com sucesso!");
        }

        [HttpPut]
        [Route("Atualizar/{id}")]
        public IActionResult Atualizar(int id, Grupo g)
        {
            var Grupo = _contexto.ObterPorId(id);
            if (Grupo == null)
            {
                return NotFound("Grupo não existe, atualização não pode ser realizada!");
            }
            _contexto.Atualizar(g);
            return Ok("Grupo atualizado com sucesso!");
        }

        [HttpDelete]
        [Route("Remover/{id}")]
        public IActionResult Remover(int id)
        {
            var Grupo = _contexto.ObterPorId(id);
            if (Grupo == null)
            {
                return NotFound("Grupo não existe, remoção não pode ser realizada!");
            }
            _contexto.Remover(id);
            return Ok();
        }
    }
}
