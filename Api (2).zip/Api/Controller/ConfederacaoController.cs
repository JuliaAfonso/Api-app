﻿using Api.Model;
using Api.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Api.Controller
{
    [Route("api/[controller]")]
    public class ConfederacaoController : ControllerBase
    {
        private IConfederacaoRepository _contexto;

        public ConfederacaoController(IConfederacaoRepository contexto)
        {
            _contexto = contexto;
        }

        //api/confederacao/ObterTodasAsConfederacoes
        [HttpGet]
        [Route("ObterTodasAsConfederacoes")]
        public IActionResult ObterTodosAsConfederacoes()
        {
            var listaConfederacoes = _contexto.ObterTodasAsConfederacao();
            return Ok(listaConfederacoes);
        }

        [HttpGet]
        [Route("ObterPorId/{id}")]
        public IActionResult ObterPorId(int id)
        {
            var confederacaoBusca = _contexto.ObterPorId(id);
            if (confederacaoBusca == null)
                return NotFound("Confederacao não encontrado");
            return Ok(confederacaoBusca);
        }

        [HttpPost]
        [Route("Adicionar")]
        public IActionResult Adicionar(Confederacao c)
        {
            _contexto.Adicionar(c);
            return Ok("Confederacao Adicionado com sucesso!");
        }

        [HttpPut]
        [Route("Atualizar/{id}")]
        public IActionResult Atualizar(int id, Confederacao c)
        {
            var confederacao = _contexto.ObterPorId(id);
            if (confederacao == null)
            {
                return NotFound("Confederacao não existe, atualização não pode ser realizada!");
            }
            _contexto.Atualizar(c);
            return Ok("Confederacao atualizado com sucesso!");
        }

        [HttpDelete]
        [Route("Remover/{id}")]
        public IActionResult Remover(int id)
        {
            var confederacao = _contexto.ObterPorId(id);
            if (confederacao == null)
            {
                return NotFound("Confederacao não existe, remoção não pode ser realizada!");
            }
            _contexto.Remover(id);
            return Ok();
        }
    }
}

