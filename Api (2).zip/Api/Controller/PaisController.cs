﻿using Api.Model;
using Api.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Controller
{
    [Route("api/[controller]")]
    public class PaisController : ControllerBase
    {
        private IPaisRepository _contexto;

        public PaisController(IPaisRepository contexto)
        {
            _contexto = contexto;
        }

        //api/pais/ObterTodosOsPaises
        [HttpGet]
        [Route("ObterTodosOsPaises")]
        public IActionResult ObterTodosOsPaises()
        {
            var listaPaises = _contexto.ObterTodosOsPaises();
            return Ok(listaPaises);
        }

        [HttpGet]
        [Route("ObterPorId/{id}")]
        public IActionResult ObterPorId(int id)
        {
            var paisBusca = _contexto.ObterPorId(id);
            if (paisBusca == null)
                return NotFound("Pais não encontrado");
            return Ok(paisBusca);
        }

        [HttpPost]
        [Route("Adicionar")]
        public IActionResult Adicionar(Paises p)
        {
            _contexto.Adicionar(p);
            return Ok("Pais Adicionado com sucesso!");
        }

        [HttpPut]
        [Route("Atualizar/{id}")]
        public IActionResult Atualizar(int id, Paises p)
        {
            var pais = _contexto.ObterPorId(id);
            if(pais == null)
            {
                return NotFound("Pais não existe, atualização não pode ser realizada!");
            }
            _contexto.Atualizar(p);
            return Ok("Pais atualizado com sucesso!");
        }

        [HttpDelete]
        [Route("Remover/{id}")]
        public IActionResult Remover(int id)
        {
            var pais = _contexto.ObterPorId(id);
            if (pais == null)
            {
                return NotFound("Pais não existe, remoção não pode ser realizada!");
            }
            _contexto.Remover(id);
            return Ok();
        }
    }
}
