﻿using Api.Model;
using Api.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Api.Controller
{
    [Route("api/[controller]")]
    public class PoteController : ControllerBase
    {
        private IPoteRepository _contexto;

        public PoteController(IPoteRepository contexto)
        {
            _contexto = contexto;
        }

        //api/potes/ObterTodosOsPotes
        [HttpGet]
        [Route("ObterTodosOsPotes")]
        public IActionResult ObterTodosOsPotes()
        {
            var listaPotes = _contexto.ObterTodosOsPotes();
            return Ok(listaPotes);
        }

        [HttpGet]
        [Route("ObterPorId/{id}")]
        public IActionResult ObterPorId(int id)
        {
            var poteBusca = _contexto.ObterPorId(id);
            if (poteBusca == null)
                return NotFound("Pote não encontrado");
            return Ok(poteBusca);
        }

        [HttpPost]
        [Route("Adicionar")]
        public IActionResult Adicionar(Pote o)
        {
            _contexto.Adicionar(o);
            return Ok("Pote Adicionado com sucesso!");
        }

        [HttpPut]
        [Route("Atualizar/{id}")]
        public IActionResult Atualizar(int id, Pote o)
        {
            var pote = _contexto.ObterPorId(id);
            if (pote == null)
            {
                return NotFound("Pote não existe, atualização não pode ser realizada!");
            }
            _contexto.Atualizar(o);
            return Ok("Pote atualizado com sucesso!");
        }

        [HttpDelete]
        [Route("Remover/{id}")]
        public IActionResult Remover(int id)
        {
            var pote = _contexto.ObterPorId(id);
            if (pote == null)
            {
                return NotFound("Pote não existe, remoção não pode ser realizada!");
            }
            _contexto.Remover(id);
            return Ok();
        }
    }
}

